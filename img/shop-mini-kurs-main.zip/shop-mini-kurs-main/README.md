"# shop-mini-kurs" 
